#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>

int main() {
	key_t key = 1001;

	int shmid = shmget(key,sizeof(int), IPC_CREAT | 0660);
	if (shmid < 0) {
		printf("Error has ocuured to aquire shared value\n");
	}
	
	int *ptr = shmat(shmid, NULL, 0);
	if (ptr ==  (void *) -1) {
		printf("Error has occured to attach to shared value\n");
		//shmctl(shmid, IPC_RMID, 0);
		return -1;
	}

	srand(time(NULL));
	int value = rand() % 10;
	*ptr = value;
	//*ptr = 2;
	shmdt(ptr);
	return 1;
}