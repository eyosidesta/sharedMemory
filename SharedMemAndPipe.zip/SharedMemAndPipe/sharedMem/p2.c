#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main() {
	key_t key = 1001;
	int value = rand() % 10;
	int shmid = shmget(key,sizeof(int), IPC_CREAT);
	if (shmid < 0) {
		printf("Error has occured to aquire shared value\n");
		return -1;
	}
	int *ptr = shmat(shmid, NULL, SHM_RDONLY);
	if (ptr ==  (void *) -1) {
		printf("Error has occured to attach to shared value\n");
		shmctl(shmid, IPC_RMID, 0);
		return -1;
	}
	//printf("%d\n", *ptr);
	if (*ptr % 2 == 0) {

		printf("The number is even\n");
	} else {
		printf("The number is odd\n");	
	}
	
	shmdt(ptr);
	shmctl(shmid, IPC_RMID, 0);
	return 1;
}